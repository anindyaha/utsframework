<?php

use App\Http\Controllers\BarangController;
use App\Http\Controllers\SatuanController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome',["title"=>"Kosmetik"]);
});
Route::controller(BarangController::class)->group(function(){
    Route::get('/barang','barang')->name('getbarang');
    Route::get('/tambahbarang','tambah')->name('formtambahbarang');
    Route::get('/ubahbarang/{id}','ubah')->name('formtambahbarang');
    Route::post('/tambahbarang','barang')->name('postbarang');
    Route::put('/ubahbarang/{id}','barang')->name('putbarang');
    Route::delete('/hapusbarang/{id}','barang')->name('deletebarang');
});
Route::controller(SatuanController::class)->group(function(){
    Route::get('/satuan','satuan')->name('getsatuan');
    Route::get('/tambahsatuan','tambah')->name('formtambahsatuan');
    Route::get('/ubahsatuan/{id}','ubah')->name('formubahsatuan');
    Route::post('/tambahsatuan','satuan')->name('postsatuan');
    Route::put('/ubahsatuan/{id}','satuan')->name('putsatuan');
    Route::delete('/hapussatuan','satuan')->name('deletesatuan');
});