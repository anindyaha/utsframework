
<?php $__env->startSection('content'); ?>
    <div class="formku">
    <p class="modal-text">Tambah Satuan</p>
                              <form action="<?php echo e(route('postsatuan')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="kode_satuan" value="<?php
                                  echo 'S'. rand(1000,9999);
                                ?>">
                                <div class="mb-3">
                                  <label class="form-label">Nama Satuan</label>
                                  <input class="form-control" type="text" name="nama_satuan" value="<?php echo e(old('nama_satuan')); ?>">
                                  <?php $__errorArgs = ['nama_satuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p><?php echo e($message); ?></p>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  <button type="submit" class="btn btn-primary">Submit</button>
</form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Elian\master-barang\resources\views/satuan/tambah.blade.php ENDPATH**/ ?>