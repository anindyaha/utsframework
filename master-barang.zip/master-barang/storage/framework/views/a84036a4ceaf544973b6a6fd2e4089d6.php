<?php $__env->startSection('content'); ?>
<h1>Selamat Datang di Penjualan Kosmetik</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Elian\master-barang\resources\views/welcome.blade.php ENDPATH**/ ?>