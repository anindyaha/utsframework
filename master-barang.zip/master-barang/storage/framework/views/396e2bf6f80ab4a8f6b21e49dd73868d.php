
<?php $__env->startSection('content'); ?>
<!-- Modal -->
<a href="/tambahsatuan" class="btn btn-primary">Tambah Barang</a>
         
          <br>
          <?php if(Session::has('success')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(Session::get('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          <?php endif; ?>
          <br>
<table class="table table-bordered table-striped table-hover">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Kode Satuan</th>
      <th scope="col">Nama satuan</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php
        $no =1;
    ?>
    <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
    <tr>
      <th scope="row"><?php echo e($no++); ?></th>
      <td><?php echo e($b->kode_satuan); ?></td>
      <td><?php echo e($b->nama_satuan); ?></td>
   
      <td>
        <div class="row">
          <div class="col col-md-3" style="padding-left: 60px;">
          <a class="btn btn-warning" href="/ubahsatuan/<?php echo e($b->id); ?>"data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa-regular fa-pen-to-square"></i></a>
          </div>
          <div class="col col-md-3" style="margin-right: -70px;">
          <form action="<?php echo e(route('deletesatuan',$b->id)); ?>" method="post">
          <?php echo csrf_field(); ?>
          <?php echo method_field('delete'); ?>
          <button class="btn btn-danger"><i class="fa-regular fa-trash-can"></i></button>
        </form>
          </div>
        </div>
        
        
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Elian\master-barang\resources\views/satuan/satuan.blade.php ENDPATH**/ ?>