<?php

namespace App\Http\Controllers;

use App\Models\Satuan;
use Illuminate\Http\Request;

class SatuanController extends Controller
{
    public function satuan(Request $request)
    {
        $satuan = Satuan::all();
        $method = $request->method();
        switch ($method) {
            case 'POST':
                $satuan = $request->validate([
                    "kode_satuan"=>"required",
                    "nama_satuan"=>"required",
                ]);
                Satuan::create($satuan);
                return redirect('/satuan')->with('success','Satuan berhasil ditambahkan');
                break;
            
            case 'PUT':
                $id=$request->route('id');
                Satuan::where('id',$id)->update([
                    "kode_satuan"=>$request->kode_satuan,
                    "nama_satuan"=>$request->nama_satuan
                ]);
                $request->validate([
                    "kode_satuan"=>'required',
                    "nama_satuan"=>'required'
                ]);
                return redirect('/satuan')->with('success','Satuan berhasil diubah');
                break;
            case 'DELETE':
                $id=$request->route('id');
                Satuan::where('id',$id)->delete();
                return redirect('/satuan')->with('success','Satuan berhasil dihapus');
                break;
        }
        return view('satuan.satuan',["title"=>"Satuan","satuan"=>$satuan]);
    }
    public function tambah()
    {
        return view('satuan.tambah',["title"=>"Tambah Satuan"]);
    }
    public function ubah($id)
    {
        $satuan = Satuan::where('id',$id)->get()->first();
        return view('satuan.ubah',["title"=>"Ubah Satuan","b"=>$satuan]);
    }
}
