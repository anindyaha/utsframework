<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use App\Models\Satuan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class BarangController extends Controller
{
    public function barang(Request $request)
    {
        $method = $request->method();
        switch ($method) {
            case 'POST':
                $barang = $request->validate([
                    "kode_barang"=>"required|unique:barangs,kode_barang",
                    "nama_barang"=>"required",
                    "deskripsi_barang"=>"required",
                    "harga_barang"=>"required",
                    "satuan_barang"=>"required"
                ]);
                //$barang["kode_barang"] = "B".rand(1000,9999);
                Barang::create($barang);
                return redirect('/barang')->with('success','Barang berhasil ditambahkan');
                break;
            
            case 'PUT':
                $id = $request->route('id');
                Barang::where('id',$id)->update([
                    "kode_barang"=>$request->kode_barang,
                    "nama_barang"=>$request->nama_barang,
                    "deskripsi_barang"=>$request->deskripsi_barang,
                    "harga_barang"=>$request->harga_barang,
                    "satuan_barang"=>$request->satuan_barang
                ]);
                $request->validate([
                    "kode_barang"=>'required',
                    "nama_barang"=>'required',
                    "deskripsi_barang"=>'required',
                    "harga_barang"=>'required',
                    "satuan_barang"=>'required'
                ]);
                return redirect('/barang')->with('success','Barang berhasil diubah');
                break;
            case 'DELETE':
                $id = $request->route('id');
                Barang::where('id',$id)->delete();
                return redirect('/barang')->with('success','Barang berhasil dihapus');
                break;
        }
        $barang = Barang::with('satuan')->get();
        $satuan = Satuan::all();
        return view("barang.home",["barang"=>$barang,"title"=>"Barang","satuan"=>$satuan]);
    }
    public function tambah()
    {
        $satuan = Satuan::all();
        return view('barang.tambah',["title"=>"Tambah Barang","satuan"=>$satuan]);
    }
    public function ubah($id)
    {
        $barang = Barang::where('id',$id)->get()->first();
        $satuan = Satuan::all();
        return view('barang.ubah',["title"=>"Ubah Barang","b"=>$barang,"satuan"=>$satuan]);
    }
}
