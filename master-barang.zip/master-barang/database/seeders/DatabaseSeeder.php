<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use App\Models\Barang;
use App\Models\Satuan;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        Satuan::create([
            "kode_satuan"=>"S0001",
            "nama_satuan"=>"Unit"
        ]);
        Barang::create([
            "kode_barang"=>"B0001",
            "nama_barang"=>"scarlett",
            "harga_barang"=>100000,
            "deskripsi_barang"=>"skincare",
            "satuan_barang"=>1
        ]);
    }
}
