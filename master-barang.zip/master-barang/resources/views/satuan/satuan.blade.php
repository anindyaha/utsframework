@extends('layout.app')
@section('content')
<!-- Modal -->
<a href="/tambahsatuan" class="btn btn-primary">Tambah Barang</a>
         
          <br>
          @if (Session::has('success'))
          <div class="alert alert-success alert-dismissible fade show" role="alert">
                        {{ Session::get('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
          @endif
          <br>
<table class="table table-bordered table-striped table-hover">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Kode Satuan</th>
      <th scope="col">Nama satuan</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    @php
        $no =1;
    @endphp
    @foreach ($satuan as $b )    
    <tr>
      <th scope="row">{{ $no++ }}</th>
      <td>{{ $b->kode_satuan }}</td>
      <td>{{ $b->nama_satuan }}</td>
   
      <td>
        <div class="row">
          <div class="col col-md-3" style="padding-left: 60px;">
          <a class="btn btn-warning" href="/ubahsatuan/{{ $b->id }}"data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa-regular fa-pen-to-square"></i></a>
          </div>
          <div class="col col-md-3" style="margin-right: -70px;">
          <form action="{{ route('deletesatuan',$b->id) }}" method="post">
          @csrf
          @method('delete')
          <button class="btn btn-danger"><i class="fa-regular fa-trash-can"></i></button>
        </form>
          </div>
        </div>
        
        
      </td>
    </tr>
    @endforeach
  </tbody>
</table>
@endsection