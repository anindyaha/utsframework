@extends('layout.app')
@section('content')
    <div class="formku">
    <p class="modal-text">Tambah Satuan</p>
                              <form action="{{ route('postsatuan') }}" method="POST">
                                @csrf
                                <input type="hidden" name="kode_satuan" value="@php
                                  echo 'S'. rand(1000,9999);
                                @endphp">
                                <div class="mb-3">
                                  <label class="form-label">Nama Satuan</label>
                                  <input class="form-control @error('nama_satuan')
                                      is-invalid
                                  @enderror" type="text" name="nama_satuan" value="{{ old('nama_satuan') }}">
                                  @error('nama_satuan')
                                    <p>{{ $message }}</p>
                                  @enderror
                                  <button type="submit" class="btn btn-primary">Submit</button>
</form>
    </div>
@endsection