@extends('layout.app')
@section('content')
    <div class="formku">
    <p class="modal-text">Edit Satuan {{ $b->nama_satuan }}</p>
                                        <form action="{{ route('putsatuan',$b->id) }}" method="POST">
                                          @csrf
                                          @method('put')
                                          <input type="hidden" name="kode_barang" value="{{ $b->kode_satuan }}">
                                          <div class="mb-3">
                                            <label class="form-label">Nama Barang</label>
                                            <input class="form-control" type="text" name="nama_barang" value="{{ $b->nama_satuan }}@error('nama_satuan')
                                              {{ old('nama_satuan') }}
                                            @enderror">
                                            @error('nama_satuan')
                                              <p>{{ $message }}</p>
                                            @enderror
                                            <br>
                                            <button type="submit" class="btn btn-primary">Submit</button>
</form>
    </div>
@endsection