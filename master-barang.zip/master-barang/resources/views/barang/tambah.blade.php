@extends('layout.app')
@section('content')
<div class="formku">
<p class="modal-text">Tambah Barang</p>
                              <form action="{{ route('postbarang') }}" method="POST">
                                @csrf
                                <input type="hidden" name="kode_barang" value="@php
                                  echo 'B'. rand(1000,9999);
                                @endphp">
                                <div>
                                  <label class="form-label">Nama Barang</label>
                                  <input class="form-control @error('nama_barang') is-invalid @enderror" type="text" name="nama_barang" value="{{ old('nama_barang') }}">
                                  @error('nama_barang')
                                    <p>{{ $message }}</p>
                                  @enderror
                                </div>
                                <div>
                                  <label class="form-label">Deskripsi Barang</label>
                                  <input class="form-control  @error('deskripsi_barang') is-invalid @enderror" type="text" name="deskripsi_barang" value="{{ old('deskripsi_barang') }}">
                                  @error('deskripsi_barang')
                                    <p>{{ $message }}</p>
                                  @enderror
                                </div>
                                <div>
                                  <label class="form-label">Harga Barang</label>
                                  <input class="form-control  @error('harga_barang') is-invalid @enderror" type="number" name="harga_barang" value="{{ old('harga_barang') }}">
                                  @error('harga_barang')
                                    <p>{{ $message }}</p>
                                  @enderror
                                </div>
                                <div>
                                <label class="form-label  @error('satuan_barang') is-invalid @enderror">Satuan Barang</label>
                                  <select name="satuan_barang" id="" class="form-select">
                                    @foreach ($satuan as $s)
                                      <option value="{{ $s->id }}">{{ $s->nama_satuan }}</option>
                                    @endforeach
                                  </select>
                                  @error('satuan_barang')
                                    <p>{{ $message }}</p>
                                  @enderror
                                  <br>
                                  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
@endsection