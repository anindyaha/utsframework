@extends('layout.app')
@section('content')
    
<div class="formku">
<p class="modal-text">Edit Barang {{ $b->nama_barang }}</p>
                                        <form action="{{ route('putbarang',$b->id) }}" method="POST">
                                          @csrf
                                          @method('put')
                                          <input type="hidden" name="kode_barang" value="{{ $b->kode_barang }}">
                                          <div class="mb-3">
                                            <label class="form-label">Nama Barang</label>
                                            <input class="form-control" type="text" name="nama_barang" value="{{ $b->nama_barang }}@error('nama_barang')
                                              {{ old('nama_barang') }}
                                            @enderror">
                                            @error('nama_barang')
                                              <p>{{ $message }}</p>
                                            @enderror
                                          </div>
                                          <div class="mb-3">
                                            <label class="form-label">Deskripsi Barang</label>
                                            <input class="form-control" type="text" name="deskripsi_barang" value="{{ $b->deskripsi_barang }}">
                                            @error('deskripsi_barang')
                                              <p>{{ $message }}</p>
                                            @enderror
                                          </div>
                                          <div class="mb-3">
                                            <label class="form-label">Harga Barang</label>
                                            <input class="form-control" type="number" name="harga_barang" value="{{ $b->harga_barang }}">
                                            @error('harga_barang')
                                              <p>{{ $message }}</p>
                                            @enderror
                                          </div>
                                          <div class="mb-3">
                                          <label class="form-label">Satuan Barang</label>
                                            <select name="satuan_barang" id="" class="form-select">
                                              <option value="{{ $b->satuan->id }}">{{ $b->satuan->nama_satuan }}&nbsp;<em>(selected)</em></option>
                                              <option value="">----------------------------</option>
                                              @foreach ($satuan as $s)
                                                <option value="{{ $s->id }}">{{ $s->nama_satuan }}</option>
                                              @endforeach
                                            </select>
                                            @error('satuan_barang')
                                              <p>{{ $message }}</p>
                                            @enderror
                                            <br>
                                            <button type="submit" class="btn btn-primary" >Submit</button>
</form>
                                            </div>
@endsection