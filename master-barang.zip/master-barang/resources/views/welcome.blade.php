@extends('layout.app')
@section('content')
<h1>Selamat Datang di Penjualan Kosmetik</h1>
@endsection